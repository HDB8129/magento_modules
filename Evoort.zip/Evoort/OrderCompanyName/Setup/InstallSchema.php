<?php

namespace Evoort\OrderCompanyName\Setup;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{

	public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
	{
			$setup->getConnection()->addColumn(
  			  $setup->getTable('sales_order_grid'),
   					 'billing_company',
   					 [
   					     'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
    				    'comment' => 'Company Name'
   					 ]
			);
	}
}