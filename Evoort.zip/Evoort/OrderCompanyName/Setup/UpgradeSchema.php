<?php
namespace Evoort\OrderCompanyName\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if(version_compare($context->getVersion(), '1.0.1', '<')) {
        $connection = $setup->getConnection();
            $grid = $setup->getTable('sales_order_grid');
            $company_name = $setup->getTable('customer_grid_flat');

            $connection->query(
                $connection->updateFromSelect(
                    $connection->select()
                        ->join(
                            $company_name,
                            sprintf('%s.entity_id = %s.customer_id', $company_name, $grid),
                            'billing_company'
                        ),
                    $grid
                )
            );
        }
        $setup->endSetup();
    }
}